# Ledger — Inflation Calculator

A single-file static web app (HTML + CSS + JS, no build step, no dependencies)
that estimates inflation-adjusted value, purchasing power change, and
savings-vs-inflation profit/loss for 12 countries, with historical (2000–2026)
and projected (2027–2031) data, multiple chart types, and a step-by-step
calculation breakdown.

## Files
- `index.html` — the entire app (this is the only file that matters)
- `vercel.json` — minor static-hosting config (optional, safe to delete)

## Deploy to Vercel

### Option A — Vercel CLI (fastest)
```bash
npm i -g vercel
cd this-folder
vercel
```
Follow the prompts (link/create a project). Vercel auto-detects this as a
static site since there's no framework config — no build command needed.
Run `vercel --prod` to push straight to production.

### Option B — GitHub + Vercel dashboard
1. Push this folder to a new GitHub repo.
2. Go to vercel.com → **Add New Project** → import that repo.
3. Framework Preset: **Other** (or "No Framework"). Leave Build Command and
   Output Directory blank — Vercel will serve `index.html` as-is.
4. Click **Deploy**.

### Option C — Drag and drop
1. Go to vercel.com/new.
2. Drag this folder (containing `index.html`) onto the page.
3. Deploy.

No environment variables, no build step, no server — it's 100% static and
runs entirely in the browser. All data is bundled sample data (see the
About tab in-app); calculation history is stored in each visitor's own
browser via `localStorage`, not on any server.
